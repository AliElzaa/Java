
public class AccountTest {
	



	    public static void main(String[] args){ //this is our main method

	        Account account_test = new Account("bob", 3443434, 3); //here we create a new instance of the constructor

	        account_test.printAll(); //here we print it out to test to see if it works
	    }
	}

